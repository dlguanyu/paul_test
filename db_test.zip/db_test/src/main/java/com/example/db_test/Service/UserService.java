package com.example.db_test.Service;

import com.example.db_test.Entity.Person;
import com.example.db_test.Mapper.UserMapper;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    UserMapper userMapper;

    @Autowired
    private RedisTemplate redisTemplate;

    @Cacheable(value = "person")
    public Person SelectById(Long id) {
        return userMapper.SelectById(id);
    }

    @RabbitListener(queues = "topic.queue")
    public void MqReceive (Person person){
        System.out.println(person);
    }
}

