package com.example.db_test.Controller;

import com.example.db_test.Dao.JPA;
import com.example.db_test.Entity.Person;
import com.example.db_test.Service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@Slf4j
public class TestController {
    @Autowired
    private JPA personRepository;
    @Autowired
    private UserService userService;

    @GetMapping("addPerson")
    public String addPerson(Person person) {
        personRepository.save(person);
        return "person";
    }

    @GetMapping("getPerson/{id}")
    @ResponseBody
    public Person getPerson(@PathVariable("id") Long id) {
        //return personRepository.getOne(id);
        return personRepository.getPersonByID(id);
    }

    @GetMapping("getAllPerson")
    @ResponseBody
    public List<Person> getAllPerson() {
        return personRepository.getAllPerson();
    }

    @GetMapping("getMybatisPerson/{id}")
    @ResponseBody
    public Person getMybatisPerson(@PathVariable("id") Long id) {
        return userService.SelectById(id);
    }


    @GetMapping("deletePerson/{id}")
    @ResponseBody
    public String deletePerson(@PathVariable("id") Long id) {
        personRepository.deleteById(id);
        return "delete";
    }
}
