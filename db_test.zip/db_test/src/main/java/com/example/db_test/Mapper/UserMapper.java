package com.example.db_test.Mapper;

import com.example.db_test.Entity.Person;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserMapper {
    @Select("select * from person where id = #{id}")
    Person SelectById(Long id);
}
