package com.example.db_test;

import com.alibaba.fastjson.JSON;
import com.example.db_test.Entity.Person;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.common.xcontent.XContentType;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.amqp.RabbitTemplateConfigurer;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;

@SpringBootTest
@Slf4j
class DbTestApplicationTests {

    @Autowired
    private AmqpTemplate amqpTemplate;

    @Autowired
    AmqpAdmin amqpAdmin;

    @Autowired
    private RestHighLevelClient restHighLevelClient;

    @Test
    void contextLoads() {

        amqpTemplate.convertAndSend("fanout.test","fanout.queue",new Person(123L,"mike", 33));
    }

    @Test
    void contextLoads1() {

        Object o = amqpTemplate.receiveAndConvert("topic.queue");
        System.out.println(o);
    }

    @Test
    void contextLoads2() {
        amqpAdmin.declareExchange(new DirectExchange("Code.Create_DE"));
        amqpAdmin.declareQueue(new Queue("Code.Create_Q"));
        amqpAdmin.declareBinding(new Binding("Code.Create_Q", Binding.DestinationType.QUEUE,"Code.Create_DE","Code_RouteKey",null));
    }

    //创建文档
    @Test
    public void createDocument() throws IOException {
        //创建对象
        Person userInfo = new Person(666L,"DA",12);
        //创建请求
        IndexRequest request = new IndexRequest("JAVA");
        //规则
        request.id("1").timeout(TimeValue.timeValueSeconds(1));
        //将数据放到请求中
        request.source(JSON.toJSONString(userInfo), XContentType.JSON);
        //客户端发送请求，获取相应的结果
        IndexResponse response = restHighLevelClient.index(request, RequestOptions.DEFAULT);
        //打印一下
        System.out.println(response.toString());
        System.out.println(response.status());
    }
}
